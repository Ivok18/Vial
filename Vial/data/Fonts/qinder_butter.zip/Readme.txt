Hello,



Thank you for downloading font from Hadjar Creative.

This font is perfect for your work design.

Hope you enjoy this font and make your work easier.



THE RULES:

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is ONLY for PERSONAL USE and NON-PPROFIT. NO COMMERCIAL USE ALLOWED!!!
  If you make money from using my fonts, Please purchase a COMMERCIAL LICENSE.

- You can purchase it in my shop here :
  https://fontbundles.net/hadjar-creative

- If you need a Custom or corporate COMMERCIAL LICENSE please contact me via email at
  hadjarcreative@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://www.paypal.me/misasulaiman
  I really appreciate your donations no matter how much.



GUIDES:

- This font can be used in various computer software,aspecially design software.

- To acces special characters you can use opentype feature on your design sorftware. Or access Character Map for Windows user, Font Book for MAC user.

- This font is PUA encoded which means you can access all of the glyps and alternate with ease. 



CAUTION!!!

Someone who use my PERSONAL USE fonts for COMMERCIAL whithout buying COMMERCIAL LICENSE and without permission from the author, will be subject to fines!



GOOD NEWS!!!

Get discount price for commercial font in https://fontbundles.net/hadjar-creative. 

Big discount price. Get it soon. 

Limited time.Limmited opportunities for you.



Thank you for your appericiation.


Kind Regards.

Hadjar Creative